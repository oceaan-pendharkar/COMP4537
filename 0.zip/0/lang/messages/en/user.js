//This file was created with the help of github copilot and chatGPT
const UserMessages = {
  invalidInput: "Please enter a number between 3 and 7.",
  wrongOrder: "Wrong order!",
  excellentMemory: "Excellent Memory!",
  numberOfButtonsText: "How many buttons to create?",
  go: "Go!",
  title: "Lab 0: Button Game",
  placeholder: "Enter a number between 3 and 7",
};

export default UserMessages;
